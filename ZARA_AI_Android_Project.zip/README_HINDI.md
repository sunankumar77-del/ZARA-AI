# ZARA AI — Android Studio starter project

यह एक नया Android ऐप starter है: dark/purple UI, Groq chat, Android speech recognition, और text-to-speech।

## ज़रूरी बातें
- यह तैयार APK नहीं है; यह Android Studio में build करने वाला source project है।
- API key ऐप की Settings में डालें। किसी से key साझा न करें। सार्वजनिक रूप से APK बाँटने पर ऐप के भीतर रखी key निकाली जा सकती है; production ऐप के लिए सुरक्षित backend proxy बेहतर है।
- Voice recognition Android के speech service पर निर्भर है; हर फोन पर offline काम करने की गारंटी नहीं।
- Home स्क्रीन पर फिलहाल placeholder ZARA orb है। दिए गए reference screenshot की लड़की की तस्वीर इस starter में शामिल नहीं है।
- Create Image अभी वास्तविक image-generation backend से जुड़ा नहीं है।

## Build करने के चरण
1. कंप्यूटर पर Android Studio install करें।
2. Android Studio में **Open** चुनें और इस folder को खोलें।
3. Gradle sync पूरा होने दें; जरूरत हो तो Android SDK 35 install करें।
4. फोन में Developer options और USB debugging चालू करके फोन कनेक्ट करें, या emulator चुनें।
5. **Run ▶** दबाएँ।
6. ऐप में Settings खोलें। Groq API key और सही model name भरें, फिर Save करें।
7. Chat में टेक्स्ट भेजकर कनेक्शन जाँचें। Voice इस्तेमाल करने के लिए microphone permission दें।

## APK बनाना
Android Studio में **Build → Build Bundle(s) / APK(s) → Build APK(s)** चुनें। APK आमतौर पर `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा।

## Troubleshooting
- `401`: API key गलत/रद्द की गई है।
- `404` या model error: Groq Console में उपलब्ध model ID जाँचें।
- Voice input नहीं चलता: microphone permission दें और Android Speech Recognition/Google app की उपलब्धता जाँचें।
