package com.zaraai.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private val Bg = Color(0xFF080713)
private val Panel = Color(0xFF17152D)
private val Purple = Color(0xFF8748FF)
private val Cyan = Color(0xFF13D6EA)
private val Muted = Color(0xFFA9A5C8)

data class ChatLine(val user: Boolean, val text: String)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
            }
        }
        setContent { ZaraApp(
            onSpeak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "zara_reply") },
            onListen = { callback -> startListening(callback) }
        ) }
    }

    private fun startListening(callback: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            callback("इस डिवाइस पर Speech Recognition उपलब्ध नहीं है।")
            return
        }
        val launch = {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { recognizer.destroy() }
                override fun onResults(results: Bundle?) {
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!spoken.isNullOrBlank()) callback(spoken)
                    recognizer.destroy()
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            recognizer.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "ZARA से बात करें")
            })
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launch()
        else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 701)
        // User can tap the microphone again after granting permission.
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun ZaraApp(onSpeak: (String) -> Unit, onListen: ((String) -> Unit) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("zara_settings", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "openai/gpt-oss-20b") ?: "openai/gpt-oss-20b") }
    var page by remember { mutableStateOf("Home") }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var reply by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatLine>() }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Purple, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("ZARA", fontSize = 31.sp, fontWeight = FontWeight.Black, color = Color.White)
                Text("AI", fontSize = 31.sp, fontWeight = FontWeight.Black, color = Purple)
                IconButton(onClick = { page = "Settings" }) { Icon(Icons.Default.Settings, null, tint = Color.White) }
            }
            when (page) {
                "Settings" -> {
                    Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(22.dp))
                    Text("Groq API configuration", color = Muted, modifier = Modifier.padding(horizontal = 22.dp))
                    OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Groq API Key") },
                        modifier = Modifier.fillMaxWidth().padding(16.dp), singleLine = true)
                    OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Model name") },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), singleLine = true)
                    Button(onClick = {
                        prefs.edit().putString("api_key", apiKey.trim()).putString("model", model.trim()).apply()
                        page = "Home"
                    }, modifier = Modifier.fillMaxWidth().padding(16.dp)) { Text("Save settings") }
                    Text("Use your own key. Do not share it or include it in a public APK.", color = Muted,
                        modifier = Modifier.padding(20.dp))
                }
                "Chat", "History" -> {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp)) {
                        items(messages) { line ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                colors = CardDefaults.cardColors(containerColor = if (line.user) Color(0xFF4D2A91) else Panel)) {
                                Text(line.text, Modifier.padding(14.dp), color = Color.White)
                            }
                        }
                        if (loading) item { Text("ZARA सोच रही है…", color = Cyan, modifier = Modifier.padding(12.dp)) }
                    }
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(input, { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("कुछ पूछें…") })
                        IconButton(onClick = { onListen { input = it } }) { Icon(Icons.Default.Mic, null, tint = Purple) }
                        IconButton(onClick = {
                            val prompt = input.trim()
                            if (prompt.isNotEmpty() && !loading) {
                                messages.add(ChatLine(true, prompt)); input = ""; loading = true
                                scope.launch {
                                    val answer = askGroq(apiKey, model, prompt)
                                    messages.add(ChatLine(false, answer)); reply = answer; loading = false
                                    onSpeak(answer)
                                }
                            }
                        }) { Icon(Icons.Default.Send, null, tint = Purple) }
                    }
                }
                else -> {
                    Column(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Box(Modifier.size(260.dp).background(
                            Brush.linearGradient(listOf(Color(0xFF29145B), Color(0xFF0C6A80), Color(0xFF6D36C7))),
                            RoundedCornerShape(34.dp)), contentAlignment = Alignment.Center) {
                            Text("ZARA", fontSize = 56.sp, fontWeight = FontWeight.Black, color = Color.White)
                        }
                        Spacer(Modifier.height(24.dp))
                        Text("Always Here For You", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Your personal AI assistant", color = Muted, modifier = Modifier.padding(8.dp))
                        Spacer(Modifier.height(18.dp))
                        Button(onClick = { page = "Chat" }, shape = CircleShape,
                            modifier = Modifier.size(142.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                            Icon(Icons.Default.Mic, "Talk", modifier = Modifier.size(48.dp))
                        }
                        Text("Tap to Talk", color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(12.dp))
                        OutlinedButton(onClick = { page = "Chat" }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
                            Icon(Icons.Default.Chat, null); Spacer(Modifier.width(8.dp)); Text("Chat")
                        }
                        OutlinedButton(onClick = { page = "Chat"; input = "Help me write something" },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("Write") }
                        OutlinedButton(onClick = { page = "History" }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                            Icon(Icons.Default.History, null); Spacer(Modifier.width(8.dp)); Text("History")
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), horizontalArrangement = Arrangement.SpaceAround) {
                listOf("Home", "Chat", "History", "Settings").forEach { item ->
                    Text(item, color = if (page == item) Purple else Muted,
                        modifier = Modifier.clickable { page = item }.padding(10.dp), fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

private suspend fun askGroq(apiKey: String, model: String, prompt: String): String = withContext(Dispatchers.IO) {
    if (apiKey.isBlank()) return@withContext "Settings में Groq API key डालें और Save करें।"
    try {
        val json = JSONObject().apply {
            put("model", model.ifBlank { "openai/gpt-oss-20b" })
            put("messages", JSONArray().put(JSONObject().put("role", "system")
                .put("content", "You are ZARA, a helpful assistant. Reply in the same language as the user."))
                .put(JSONObject().put("role", "user").put("content", prompt)))
            put("temperature", 0.7)
            put("max_tokens", 512)
        }
        val request = Request.Builder().url("https://api.groq.com/openai/v1/chat/completions")
            .addHeader("Authorization", "Bearer ${apiKey.trim()}")
            .addHeader("Content-Type", "application/json")
            .post(json.toString().toRequestBody("application/json".toMediaType())).build()
        OkHttpClient().newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) "API error ${response.code}: ${JSONObject(body).optString("error", body)}"
            else JSONObject(body).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
    } catch (e: Exception) {
        "Connection error: ${e.message ?: "कृपया इंटरनेट और API key जाँचें।"}"
    }
}
